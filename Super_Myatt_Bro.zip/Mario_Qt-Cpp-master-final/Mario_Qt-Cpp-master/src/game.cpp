#include "game.h"

game::game()
    :m_score(0)

{
}

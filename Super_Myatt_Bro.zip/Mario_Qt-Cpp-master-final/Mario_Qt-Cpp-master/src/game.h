#ifndef GAME_H
#define GAME_H

class game
{
public:
    game();
    int m_score;
};

#endif // GAME_H
